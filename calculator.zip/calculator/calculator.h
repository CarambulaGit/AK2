#ifndef CALCULATOR_H
#define CALCULATOR_H

class Calculator
{
	public:
		Calculator();
		int Add (double, double);
		int Sub (double, double);
};

#endif//CALCULATOR_H
