#include <iostream>
#include "calculator.h"

using namespace std;


int main() {
    cout << "Main start";
    Calculator* calculator = new Calculator();
    cout << "Main end";
}